# Resources

- [MLFlow Experiment on DagsHub](https://dagshub.com/macm1/Machine_learning_project/experiments)
- [Docker Hub Container](https://hub.docker.com/r/kundansatkar/machinelearning)
- [Streamlit App](http://192.168.1.42:8501)