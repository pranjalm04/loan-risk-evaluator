# code

[Open Project](Loan_application_risk_evaluation.ipynb)